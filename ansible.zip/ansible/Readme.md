1st Step-add ssh private key:
run command:
    eval `ssh-agent -s`
    ssh-add GroupKey.txt
2nd Step:
run command:
    ~/ansible/run_ansible_launch_nectar.sh