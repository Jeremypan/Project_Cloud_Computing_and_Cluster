import geopandas as gpd
import pandas as pd
from shapely.geometry.polygon import Polygon
from shapely.geometry.multipolygon import MultiPolygon

#################################################Process Data####################################################
melb=pd.read_csv('data_v1.csv')
loca_data=gpd.read_file('Output__spatialise-dataset_May-04_22_03/shp/274cdfb9-b635-4e1d-8f80-54bcb4e1d8c5.shp')
melb=melb.iloc[:,:-2]
melb_geo=pd.merge(melb,loca_data[['sa2_name16','geometry']],how='left',on='sa2_name16')

def explode(indata):
    #indf = gpd.GeoDataFrame.from_file(indata)
    indf=indata
    outdf = gpd.GeoDataFrame(columns=indf.columns)
    for idx, row in indf.iterrows():
        if type(row.geometry) == Polygon:
            outdf = outdf.append(row,ignore_index=True)
        if type(row.geometry) == MultiPolygon:
            multdf = gpd.GeoDataFrame(columns=indf.columns)
            recs = len(row.geometry)
            multdf = multdf.append([row]*recs,ignore_index=True)
            for geom in range(recs):
                multdf.loc[geom,'geometry'] = row.geometry[geom]
            outdf = outdf.append(multdf,ignore_index=True)
    return outdf

melb_geo=explode(melb_geo)

melb_geo['x_loc']=melb_geo.geometry.apply(lambda x: x.exterior.coords.xy[0])
melb_geo['y_loc']=melb_geo.geometry.apply(lambda x: x.exterior.coords.xy[1])
melb_geo['x_loc']=melb_geo['x_loc'].apply(lambda x: list(x))
melb_geo['y_loc']=melb_geo['y_loc'].apply(lambda x: list(x))

######################################################Plot######################################################
from bokeh.plotting import figure,output_file,show,ColumnDataSource
from bokeh.models import ColumnarDataSource,HoverTool,Select,ColorBar,TapTool
from bokeh.layouts import gridplot,column,row,widgetbox
from bokeh.plotting import curdoc
from bokeh.transform import linear_cmap
from bokeh.palettes import Spectral6,Spectral9

source=ColumnDataSource()
source.data={'x':melb_geo['irsad_score'],'y':melb_geo['per100_no_emergency_money_synth'],
              'size':melb_geo['totalpers_synth']/1000,'suburb':melb_geo['sa2_name16'],
             'x_loc':melb_geo['x_loc'],'y_loc':melb_geo['y_loc'],'color':melb_geo['totalpers_synth'],
            'totalpers_synth':melb_geo['totalpers_synth'],'inc_median_syn':melb_geo['inc_median_syn'],
             'q1_perc':melb_geo['q1_perc'], 'q2_perc':melb_geo['q2_perc'],'q3_perc':melb_geo['q3_perc'],
            'q4_perc':melb_geo['q4_perc'],'per100_no_emergency_money_synth':melb_geo['per100_no_emergency_money_synth'],
            'irsad_score':melb_geo['irsad_score'],'ieo_score':melb_geo['ieo_score'],
            'poor_hlth_me_2_rate_3_11_7_13':melb_geo['poor_hlth_me_2_rate_3_11_7_13']}


p1=figure(active_scroll="wheel_zoom",sizing_mode='scale_height',
          title='per100_no_emergency_money vs irsad_score, circle size = totalpers', 
          x_axis_label='irsad_score',y_axis_label='per100_no_emergency_money',width=700)

hvt=HoverTool(tooltips=[('Suburb','@suburb'),('x','@x'),('y','@y'),('size','@size'),('','size qeuals (totalpers/1000)')])
p1.circle('x','y',source=source,size='size',alpha=0.5,hover_alpha=1)
p1.add_tools(hvt)

options_list=['totalpers_synth', 'inc_median_syn','q1_perc', 'q2_perc', 'q3_perc', 'q4_perc',
              'per100_no_emergency_money_synth', 'irsad_score', 'ieo_score','poor_hlth_me_2_rate_3_11_7_13']
select_x = Select(title="x:", value="irsad_score", options=options_list,sizing_mode='scale_width')
select_y = Select(title="y:", value="per100_no_emergency_money_synth", options=options_list,sizing_mode='scale_width')
#select_size = Select(title="size:", value="totalpers_synth", options=options_list)
    
def update_plot(attr, old, new):
    x=select_x.value
    y=select_y.value
    #size=select_size.value
    source.data['x']=melb_geo[x]
    source.data['y']=melb_geo[y]  
    p1.xaxis.axis_label=x
    p1.yaxis.axis_label=y
    p1.title.text = '%s vs %s, circle size = totalpers' % (select_x.value,select_y.value)
    
select_x.on_change('value', update_plot)
select_y.on_change('value', update_plot)
#select_size.on_change('value', update_plot)

#####################################Map plot########################################
map_plot=figure(active_scroll="wheel_zoom",width=700,sizing_mode='scale_height',
                title='Melbourne heat map, color = totalpers')

mapper = linear_cmap(field_name='color',palette=Spectral6,low=min(source.data['color']),high=max(source.data['color']))
map_plot.patches('x_loc','y_loc',source=source,line_color='black',alpha=0.5,hover_alpha=1,color=mapper)
color_bar = ColorBar(color_mapper=mapper['transform'], width=8,location=(0,0))
map_plot.add_layout(color_bar, 'right')
hvt2=HoverTool(tooltips=[('Suburb','@suburb'),('totalpers','@color'),('inc_median','@inc_median_syn'),
      ('q1_perc','@q1_perc'),('q2_perc','@q2_perc'),('q3_perc','@q3_perc'),('q4_perc','@q4_perc'),
     ('no_emergency_money_rate','@per100_no_emergency_money_synth'),('irsad_score','@irsad_score'),
     ('ieo_score','@ieo_score'),('poor_health_rate','@poor_hlth_me_2_rate_3_11_7_13')])
map_plot.add_tools(hvt2)
tp=TapTool()
map_plot.add_tools(tp)
p1.add_tools(tp)
map_plot.xaxis.visible = False
map_plot.yaxis.visible = False
map_plot.xgrid.grid_line_color = None
map_plot.ygrid.grid_line_color = None

select_tools=row(select_x,select_y)
layout=column(select_tools,p1)

output_file("p1.html")
curdoc().add_root(row(map_plot,layout))



